"""
配置文件
"""
import os

# LOL客户端默认安装路径
DEFAULT_LOL_PATHS = [
    r"C:\Riot Games\League of Legends",
    r"D:\Riot Games\League of Legends",
]

# API配置
OPGG_API_URL = "https://api.op.gg"
REQUEST_TIMEOUT = 10

# UI配置
WINDOW_TITLE = "Symbol Acceptor"
WINDOW_WIDTH = 350          # 默认窗口宽度
WINDOW_HEIGHT = 150         # 默认窗口高度（减小一些高度）
WINDOW_MIN_WIDTH = 350      # 最小宽度
WINDOW_MIN_HEIGHT = 100     # 最小高度，避免窗口过高

# 缓存配置
CACHE_EXPIRE_HOURS = 1

# 英雄头像API
ICON_BASE_URL = "https://ddragon.leagueoflegends.com/cdn/14.1.1/img/profileicon/"
